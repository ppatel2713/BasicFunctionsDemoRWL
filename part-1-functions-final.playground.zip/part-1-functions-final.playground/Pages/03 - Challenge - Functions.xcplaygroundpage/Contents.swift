//: [⇐ Previous: 02 - Functions](@previous)
//: ## Episode 03 - Challenge - Functions

/*:
 ## Challenge 1
 Write a function that:
 - Takes at least two `String` parameters
 - Has a default value for one parameter
 - Returns a `String`
 - Combines the two parameters in some way and returns the result
 
 You can add any other parameters you like, and you can modify or add anything you want to concatenated strings!
*/

// TODO: Write solution here

func generateTwitterHandle(name: String, anotherWord word: String = "Meow") -> String {
  name.lowercased() + word
}

generateTwitterHandle(name: "Ozma")

func deutschify(_ word1: String, _ word2: String = "katzen") -> String {
  let adjective = ["Frölich", "Rund", "Salzig", "Schwarze"].randomElement()!
  let ending = ["schule", "keit", "maler", "maschine"].randomElement()!
  
  return adjective + " " + word1 + " " + word2 + " " + ending
}


let str1 : String = deutschify("swifty")
print(str1)
let str2 : String = deutschify("arctic", "tree")
print(str2)


func combineNameFunc(Firstname firstName : String, LastName lastName : String = "Patel") -> String
{
    
    return firstName.uppercased() + " " + lastName
}

let name1 = combineNameFunc(Firstname: "Prachi")
print(name1)

let name2 = combineNameFunc(Firstname: "Jenny", LastName: "D'Za")
print(name2)

func combineNameFunc2(FName fname : String, LName lname : String)-> String
{
    let nameArr = ["abc","def","hij"].randomElement()!
    let lastNameArr = ["aa","bb","cc"].randomElement()!
    return fname + " " + nameArr + " " + lastNameArr + " " + lname
}

let name12 = combineNameFunc2(FName: "pp", LName: "gg")
print(name12)
//: [⇒ Next: 04 - Overloading](@next)
